#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#include <wrl.h>
#include <cstdarg>
#include <iostream>
#include <vector>

#include <d3d11.h>
#pragma comment (lib, "dxgi.lib")
#pragma comment (lib, "d3d11.lib")

#define XR_USE_PLATFORM_WIN32
#define XR_USE_GRAPHICS_API_D3D11
#include <openxr/openxr.h>
#include <openxr/openxr_platform.h>
#include <openxr/openxr_reflection.h>
#include <openxr/fb_eye_tracking_social.h>

#ifndef _DEBUG
#define _DEBUG
#endif
#include <cassert>

void Log(const char* fmt, ...) {
	va_list va;
	va_start(va, fmt);
	char buf[1024];
	vsnprintf_s(buf, sizeof(buf), _TRUNCATE, fmt, va);
	std::cout << buf;
	OutputDebugStringA(buf);
	va_end(va);
}

int main()
{
	XrResult result;
	XrInstance instance = XR_NULL_HANDLE;
	XrSystemId system = XR_NULL_SYSTEM_ID;
	XrSession session = XR_NULL_HANDLE;
	XrEyeTrackerFB eyeTracker = XR_NULL_HANDLE;

	XrInstanceCreateInfo instanceInfo{ XR_TYPE_INSTANCE_CREATE_INFO };
	instanceInfo.applicationInfo.apiVersion = XR_CURRENT_API_VERSION;
	sprintf_s(instanceInfo.applicationInfo.applicationName, sizeof(instanceInfo.applicationInfo.applicationName),
		"TestOculusEyeTracker");
	std::vector<const char*> extensions;
	extensions.push_back(XR_KHR_D3D11_ENABLE_EXTENSION_NAME);
	extensions.push_back(XR_FB_EYE_TRACKING_SOCIAL_EXTENSION_NAME);
	instanceInfo.enabledExtensionCount = (uint32_t)extensions.size();
	instanceInfo.enabledExtensionNames = extensions.data();
	result = xrCreateInstance(&instanceInfo, &instance);
	if (XR_FAILED(result)) {
		Log("Failed to create instance: %d\n", result);
		return 1;
	}

	XrSystemGetInfo systemInfo{ XR_TYPE_SYSTEM_GET_INFO };
	systemInfo.formFactor = XR_FORM_FACTOR_HEAD_MOUNTED_DISPLAY;
	result = xrGetSystem(instance, &systemInfo, &system);
	assert(XR_SUCCEEDED(result));

	PFN_xrGetD3D11GraphicsRequirementsKHR pfnXrGetD3D11GraphicsRequirementsKHR = nullptr;
	result = xrGetInstanceProcAddr(instance, "xrGetD3D11GraphicsRequirementsKHR",
		(PFN_xrVoidFunction*)&pfnXrGetD3D11GraphicsRequirementsKHR);
	assert(XR_SUCCEEDED(result));

	XrGraphicsRequirementsD3D11KHR graphicsRequirements{ XR_TYPE_GRAPHICS_REQUIREMENTS_D3D11_KHR };
	result = pfnXrGetD3D11GraphicsRequirementsKHR(instance, system, &graphicsRequirements);
	assert(XR_SUCCEEDED(result));

	Microsoft::WRL::ComPtr<ID3D11Device> device;
	{
		HRESULT hr;
		Microsoft::WRL::ComPtr<IDXGIFactory1> dxgiFactory;
		hr = CreateDXGIFactory1(IID_PPV_ARGS(dxgiFactory.ReleaseAndGetAddressOf()));
		assert(SUCCEEDED(hr));

		Microsoft::WRL::ComPtr<IDXGIAdapter1> dxgiAdapter;
		for (UINT adapterIndex = 0;; adapterIndex++) {
			hr = dxgiFactory->EnumAdapters1(adapterIndex, dxgiAdapter.ReleaseAndGetAddressOf());
			assert(SUCCEEDED(hr));

			DXGI_ADAPTER_DESC1 desc;
			hr = dxgiAdapter->GetDesc1(&desc);
			assert(SUCCEEDED(hr));
			if (!memcmp(&desc.AdapterLuid, &graphicsRequirements.adapterLuid, sizeof(LUID))) {
				break;
			}
		}

		hr = D3D11CreateDevice(dxgiAdapter.Get(),
			D3D_DRIVER_TYPE_UNKNOWN,
			0,
			0,
			&graphicsRequirements.minFeatureLevel,
			1,
			D3D11_SDK_VERSION,
			device.ReleaseAndGetAddressOf(),
			nullptr,
			nullptr);
		assert(SUCCEEDED(hr));
	}

	XrSessionCreateInfo sessionInfo{ XR_TYPE_SESSION_CREATE_INFO };
	sessionInfo.systemId = system;
	XrGraphicsBindingD3D11KHR d3d11Bindings{ XR_TYPE_GRAPHICS_BINDING_D3D11_KHR };
	d3d11Bindings.device = device.Get();
	sessionInfo.next = &d3d11Bindings;
	result = xrCreateSession(instance, &sessionInfo, &session);
	assert(XR_SUCCEEDED(result));

#if 1
	XrSessionBeginInfo beginInfo{ XR_TYPE_SESSION_BEGIN_INFO };
	beginInfo.primaryViewConfigurationType = XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO;
	result = xrBeginSession(session, &beginInfo);
	assert(XR_SUCCEEDED(result));
#endif

	PFN_xrCreateEyeTrackerFB pfnXrCreateEyeTrackerFB = nullptr;
	result = xrGetInstanceProcAddr(instance, "xrCreateEyeTrackerFB",
		(PFN_xrVoidFunction*)&pfnXrCreateEyeTrackerFB);
	if (XR_FAILED(result)) {
		Log("Failed to query pointer for xrCreateEyeTrackerFB(): %d\n", result);
		return 1;
	}

	XrEyeTrackerCreateInfoFB eyeTrackerInfo{ XR_TYPE_EYE_TRACKER_CREATE_INFO_FB };
	result = pfnXrCreateEyeTrackerFB(session, &eyeTrackerInfo, &eyeTracker);
	if (XR_FAILED(result)) {
		Log("Failed to invoke xrCreateEyeTrackerFB(): %d\n", result);
		return 1;
	}

	Log("XrEyeTrackerFB handle is: %d\n", eyeTracker);

	return 0;
}
